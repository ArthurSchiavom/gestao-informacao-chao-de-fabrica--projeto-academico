.. cmake-module:: ../../Modules/FindMPI.cmake
